import csv
import paramiko
import concurrent.futures

def ssh_connect(ip, username, password):
    try:
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(ip, username=username, password=password, timeout=13, 
                    allow_agent=False, look_for_keys=False, port=22)
        return ssh
    except paramiko.AuthenticationException:
        print(f"Authentication failed for {ip}.")
    except paramiko.SSHException as e:
        print(f"Unable to establish SSH connection to {ip}: {e}")
    except Exception as e:
        print(f"Error occurred while connecting to {ip}: {e}")
    return None

def command_output_reader(ssh):
    interfaces = []
    command = "show interfaces status"
    stdin, stdout, stderr = ssh.exec_command(command)
    output = stdout.read().decode()
    for line in output.splitlines():
        data = line.strip().split()
        if len(data) >= 4:              # The length of "trunk" interfaces is above 4.
            interface_number = data[0]
            vlanNum = data[3]  # The vlan information is in the fourth column
            if "12" in vlanNum:
                interfaces.append((interface_number, vlanNum))
    return interfaces

def process_switch(ip_data):
    ip, username, password = ip_data
    try:
        ssh = ssh_connect(ip, username, password)
        if ssh:
            interfaces = command_output_reader(ssh)
            ssh.close()
            return (ip, interfaces)
    except Exception as e:
        print(f"Error occurred while processing {ip}: {e}")
    return (ip, [])

def main():
    # Read IP addresses, usernames, and passwords from the list file
    with open("switch_information.txt", "r") as ip_file:
        ip_data_list = [line.split() for line in ip_file.read().splitlines()]

    csv_filename = "output.csv"

    with open(csv_filename, mode="w", newline="") as csvfile:
        vlan_writer = csv.writer(csvfile)
        vlan_writer.writerow(["IP Address", "Interface Number", "VLAN"])

        with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
            future_to_ip = {executor.submit(process_switch, ip_data): ip_data[0] for ip_data in ip_data_list}
            for future in concurrent.futures.as_completed(future_to_ip):
                ip = future_to_ip[future]
                try:
                    result = future.result()
                    if result:
                        ip, interfaces = result
                        for interface, vlanNum in interfaces:
                            vlan_writer.writerow([ip, interface, vlanNum])
                except Exception as e:
                    print(f"Error occurred while processing {ip}: {e}")

    print(f"CSV file '{csv_filename}' created successfully.")

if __name__ == "__main__":
    main()


